"use client";

import { useEffect, useState, useCallback } from "react";
import { getSupabase, SUPABASE_ENABLED } from "@/lib/supabase";
import type { Profile, Seance, Availability, SessionType, Announcement, Lineup, Convocation } from "@/lib/espace-types";
import SocialLinks from "./SocialIcons";

const supabase = getSupabase();

const fmtDate = (iso: string) =>
  new Date(iso).toLocaleDateString("fr-FR", { weekday: "long", day: "2-digit", month: "long" });
const fmtHour = (iso: string) =>
  new Date(iso).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });

// Colonnes profil (tolérant : repli si les colonnes enrichies n'existent pas encore)
const PROFILE_COLS = "id,pseudo,role,team,poste,rank,photo_url,socials,bio";
async function fetchProfiles(): Promise<Profile[]> {
  if (!supabase) return [];
  let r = await supabase.from("profiles").select(PROFILE_COLS);
  if (r.error) r = await supabase.from("profiles").select("id,pseudo,role,team");
  return (r.data as Profile[]) || [];
}
async function fetchMyProfile(uid: string): Promise<Profile | null> {
  if (!supabase) return null;
  let r = await supabase.from("profiles").select(PROFILE_COLS).eq("id", uid).maybeSingle();
  if (r.error) r = await supabase.from("profiles").select("id,pseudo,role,team").eq("id", uid).maybeSingle();
  return (r.data as Profile) || null;
}

// Réseaux stockés en texte "Label | url" par ligne → tableau {label,url}
function parseSocialsText(txt?: string | null): { label: string; url: string }[] {
  return (txt || "").split("\n").map((l) => l.trim()).filter(Boolean).map((line) => {
    const i = line.indexOf("|");
    if (i !== -1) return { label: line.slice(0, i).trim(), url: line.slice(i + 1).trim() };
    const m = line.match(/https?:\/\/\S+/);
    return m ? { label: line.replace(m[0], "").trim(), url: m[0] } : { label: "", url: line };
  }).filter((s) => s.url);
}

// Génère et télécharge un fichier .ics (agenda) à partir des séances
function downloadICS(seances: Seance[], teamName: string) {
  const pad = (n: number) => String(n).padStart(2, "0");
  const dt = (iso: string) => {
    const d = new Date(iso);
    return `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}00Z`;
  };
  const esc = (s: string) => (s || "").replace(/([,;\\])/g, "\\$1").replace(/\n/g, "\\n");
  const now = dt(new Date().toISOString());
  const lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Eden Esport//Espace//FR", "CALSCALE:GREGORIAN", `X-WR-CALNAME:Eden ${teamName}`];
  for (const s of seances) {
    const start = new Date(s.starts_at);
    const end = new Date(start.getTime() + 2 * 3600 * 1000);
    const title = sessionTypeLabel(s.type) + (s.title ? ` — ${s.title}` : "") + (s.opponent ? ` vs ${s.opponent}` : "");
    lines.push("BEGIN:VEVENT", `UID:${s.id}@edenesport.fr`, `DTSTAMP:${now}`, `DTSTART:${dt(s.starts_at)}`, `DTEND:${dt(end.toISOString())}`, `SUMMARY:${esc(title)}`);
    if (s.location) lines.push(`LOCATION:${esc(s.location)}`);
    if (s.notes) lines.push(`DESCRIPTION:${esc(s.notes)}`);
    lines.push("END:VEVENT");
  }
  lines.push("END:VCALENDAR");
  const blob = new Blob([lines.join("\r\n")], { type: "text/calendar" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = `eden-${teamName || "planning"}.ics`; a.click();
  URL.revokeObjectURL(url);
}

/* ------------------------------------------------------------------ */
/*  Espace non configuré → message neutre (le site public n'est pas   */
/*  affecté). S'affiche tant que les variables Supabase sont absentes.*/
/* ------------------------------------------------------------------ */
function NotConfigured() {
  return (
    <div className="esp-card esp-center">
      <h2>Espace équipe — en préparation</h2>
      <p className="muted">
        L&apos;espace membres (plannings, matchs et disponibilités) sera bientôt disponible
        pour les joueurs et le staff d&apos;Eden. Reviens prochainement.
      </p>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Écran de connexion (e-mail + mot de passe)                         */
/* ------------------------------------------------------------------ */
function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [state, setState] = useState<"idle" | "sending" | "error">("idle");
  const [msg, setMsg] = useState("");

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!supabase) return;
    setState("sending");
    const { error } = await supabase.auth.signInWithPassword({
      email: email.trim(),
      password,
    });
    if (error) {
      setState("error");
      setMsg(
        /invalid login|invalid credentials|credentials/i.test(error.message)
          ? "E-mail ou mot de passe incorrect."
          : /not confirmed/i.test(error.message)
          ? "Ton compte n'est pas encore activé. Contacte le staff."
          : "Connexion impossible. Réessaie dans un instant."
      );
    }
    // succès : onAuthStateChange (racine) recharge le profil → tableau de bord
  }

  return (
    <div className="esp-card esp-center" style={{ maxWidth: 460, margin: "0 auto" }}>
      <h2>Espace équipe</h2>
      <p className="muted">Réservé aux joueurs et au staff d&apos;Eden Esport.</p>
      <form className="form" onSubmit={onSubmit} style={{ marginTop: "1rem" }}>
        <div className="field">
          <label>Ton adresse e-mail</label>
          <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)}
            placeholder="prenom@exemple.com" autoComplete="email" />
        </div>
        <div className="field">
          <label>Mot de passe</label>
          <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)}
            placeholder="Ton mot de passe" autoComplete="current-password" />
        </div>
        {state === "error" && <div className="form-ok form-err show" role="alert">{msg}</div>}
        <div>
          <button className="btn" type="submit" disabled={state === "sending"}>
            {state === "sending" ? "Connexion…" : "Se connecter"}<span className="arw">→</span>
          </button>
        </div>
        <p className="form-note">Mot de passe oublié ou pas encore de compte ? Contacte le staff.</p>
      </form>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Formulaire staff : créer une séance / un match                     */
/* ------------------------------------------------------------------ */
function CreateForm({ onCreated, defaultTeam }: { onCreated: () => void; defaultTeam: string }) {
  const [open, setOpen] = useState(false);
  const [type, setType] = useState<SessionType>("training");
  const [f, setF] = useState({ title: "", date: "", time: "", team: defaultTeam, opponent: "", location: "", notes: "" });
  const [saving, setSaving] = useState(false);
  const set = (k: string, v: string) => setF((p) => ({ ...p, [k]: v }));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!supabase || !f.date) return;
    setSaving(true);
    const starts_at = new Date(`${f.date}T${f.time || "19:00"}`).toISOString();
    const { error } = await supabase.from("sessions").insert({
      type,
      title: f.title || sessionTypeLabel(type),
      starts_at,
      team: f.team || null,
      opponent: isCompetitive(type) ? f.opponent || null : null,
      location: f.location || null,
      notes: f.notes || null,
    });
    setSaving(false);
    if (!error) {
      setF({ title: "", date: "", time: "", team: defaultTeam, opponent: "", location: "", notes: "" });
      setOpen(false);
      onCreated();
    } else {
      alert("Création impossible : " + error.message);
    }
  }

  if (!open) return <button className="btn btn--sm" onClick={() => setOpen(true)}>+ Ajouter une séance</button>;

  return (
    <form className="form esp-card" onSubmit={submit} style={{ marginBottom: "1.2rem" }}>
      <div className="esp-seg esp-seg-wrap">
        {SESSION_TYPES.map((st) => (
          <button key={st.key} type="button" className={type === st.key ? "on" : ""} onClick={() => setType(st.key)}>{st.label}</button>
        ))}
      </div>
      <div className="field"><label>Titre</label><input value={f.title} onChange={(e) => set("title", e.target.value)} placeholder={isCompetitive(type) ? "ex : Scrim vs Team X" : "ex : Entraînement visée"} /></div>
      <div className="esp-row">
        <div className="field"><label>Date</label><input type="date" required value={f.date} onChange={(e) => set("date", e.target.value)} /></div>
        <div className="field"><label>Heure</label><input type="time" value={f.time} onChange={(e) => set("time", e.target.value)} /></div>
      </div>
      <div className="esp-row">
        <div className="field"><label>Équipe</label>
          <select value={f.team} onChange={(e) => set("team", e.target.value)}>
            {TEAMS.map((t) => <option key={t.key} value={t.key}>{t.label}</option>)}
          </select>
        </div>
        {isCompetitive(type) && <div className="field"><label>Adversaire</label><input value={f.opponent} onChange={(e) => set("opponent", e.target.value)} placeholder="Nom de l'équipe" /></div>}
      </div>
      <div className="field"><label>Lieu / lien</label><input value={f.location} onChange={(e) => set("location", e.target.value)} placeholder="En ligne, salle, lien Discord…" /></div>
      <div className="field"><label>Notes</label><textarea value={f.notes} onChange={(e) => set("notes", e.target.value)} placeholder="Infos complémentaires (optionnel)"></textarea></div>
      <div style={{ display: "flex", gap: ".6rem" }}>
        <button className="btn btn--sm" type="submit" disabled={saving}>{saving ? "Enregistrement…" : "Créer"}</button>
        <button className="btn btn--ghost btn--sm" type="button" onClick={() => setOpen(false)}>Annuler</button>
      </div>
    </form>
  );
}

/* ------------------------------------------------------------------ */
/*  FEUILLE DE MATCH — composition + résultat                          */
/* ------------------------------------------------------------------ */
type LineupRow = { in: boolean; role: string; pick: string; starter: boolean };

function LineupEditor({ s, members, lineups, onDone }: {
  s: Seance; members: Record<string, Profile>;
  lineups: Lineup[]; onDone: () => void;
}) {
  const memberList = Object.values(members).sort((a, b) => (a.pseudo || "").localeCompare(b.pseudo || ""));
  const [rows, setRows] = useState<Record<string, LineupRow>>(() => {
    const init: Record<string, LineupRow> = {};
    for (const m of memberList) {
      const ex = lineups.find((l) => l.user_id === m.id);
      init[m.id] = { in: !!ex, role: ex?.role ?? m.poste ?? "", pick: ex?.pick ?? "", starter: ex ? ex.starter : true };
    }
    return init;
  });
  const [su, setSu] = useState<string>(s.score_us != null ? String(s.score_us) : "");
  const [st, setSt] = useState<string>(s.score_them != null ? String(s.score_them) : "");
  const [maps, setMaps] = useState<string>(s.maps ?? "");
  const [saving, setSaving] = useState(false);
  const upd = (id: string, k: keyof LineupRow, v: string | boolean) => setRows((p) => ({ ...p, [id]: { ...p[id], [k]: v } }));

  async function save() {
    if (!supabase) return;
    setSaving(true);
    await supabase.from("sessions").update({
      score_us: su === "" ? null : Number(su),
      score_them: st === "" ? null : Number(st),
      maps: maps || null,
    }).eq("id", s.id);
    const entries = Object.entries(rows);
    const selected = entries.filter(([, r]) => r.in);
    let ordre = 0;
    for (const [id, r] of selected) {
      await supabase.from("match_lineup").upsert(
        { session_id: s.id, user_id: id, role: r.role || null, pick: r.pick || null, starter: r.starter, ordre: ordre++ },
        { onConflict: "session_id,user_id" }
      );
    }
    const selIds = new Set(selected.map(([id]) => id));
    for (const [id] of entries) if (!selIds.has(id)) {
      await supabase.from("match_lineup").delete().eq("session_id", s.id).eq("user_id", id);
    }
    setSaving(false);
    onDone();
  }

  return (
    <div className="esp-lineup-edit">
      <div className="esp-row">
        <div className="field"><label>Notre score</label><input type="number" min={0} value={su} onChange={(e) => setSu(e.target.value)} /></div>
        <div className="field"><label>Score adverse</label><input type="number" min={0} value={st} onChange={(e) => setSt(e.target.value)} /></div>
      </div>
      <div className="field"><label>Map(s)</label><input value={maps} onChange={(e) => setMaps(e.target.value)} placeholder="ex : Ascent, Bind" /></div>
      <div className="esp-lineup-tbl">
        {memberList.length === 0 && <p className="muted">Aucun joueur dans l&apos;équipe. Ajoute des membres d&apos;abord.</p>}
        {memberList.map((m) => {
          const r = rows[m.id];
          return (
            <div className={"esp-lineup-r" + (r.in ? " on" : "")} key={m.id}>
              <label className="esp-lineup-check">
                <input type="checkbox" checked={r.in} onChange={(e) => upd(m.id, "in", e.target.checked)} />
                <strong>{m.pseudo}</strong>
              </label>
              {r.in && (
                <div className="esp-lineup-fields">
                  <input value={r.role} onChange={(e) => upd(m.id, "role", e.target.value)} placeholder="Poste" />
                  <input value={r.pick} onChange={(e) => upd(m.id, "pick", e.target.value)} placeholder="Agent / Champion" />
                  <button type="button" className={"esp-starter" + (r.starter ? " on" : "")} onClick={() => upd(m.id, "starter", !r.starter)}>
                    {r.starter ? "Titulaire" : "Remplaçant"}
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>
      <div style={{ display: "flex", gap: ".6rem", marginTop: ".8rem" }}>
        <button className="btn btn--sm" onClick={save} disabled={saving}>{saving ? "Enregistrement…" : "Enregistrer la feuille"}</button>
        <button className="btn btn--ghost btn--sm" onClick={onDone}>Fermer</button>
      </div>
    </div>
  );
}

function MatchCompo({ s, isStaff, members, lineups, onChange }: {
  s: Seance; isStaff: boolean; members: Record<string, Profile>;
  lineups: Lineup[]; onChange: () => void;
}) {
  const [editing, setEditing] = useState(false);
  const rows = lineups.filter((l) => l.session_id === s.id).sort((a, b) => a.ordre - b.ordre);
  const hasScore = s.score_us != null && s.score_them != null;
  const res = hasScore ? (s.score_us! > s.score_them! ? "win" : s.score_us! < s.score_them! ? "loss" : "draw") : null;

  if (editing) return <LineupEditor s={s} members={members} lineups={rows} onDone={() => { setEditing(false); onChange(); }} />;

  return (
    <div className="esp-compo">
      {res && (
        <span className={"esp-result esp-" + res}>
          {res === "win" ? "Victoire" : res === "loss" ? "Défaite" : "Nul"} {s.score_us}–{s.score_them}
        </span>
      )}
      {s.maps ? <span className="muted" style={{ fontSize: ".85rem", marginLeft: ".5rem" }}>{s.maps}</span> : null}
      {rows.length > 0 ? (
        <ul className="esp-compo-list">
          {rows.map((l) => (
            <li key={l.user_id}>
              <strong>{members[l.user_id]?.pseudo || "Joueur"}</strong>
              {l.role ? <span className="muted"> · {l.role}</span> : null}
              {l.pick ? <span className="esp-pick"> · {l.pick}</span> : null}
              {!l.starter ? <span className="muted"> (remplaçant)</span> : null}
            </li>
          ))}
        </ul>
      ) : (!res && <span className="muted" style={{ fontSize: ".85rem" }}>Compo non renseignée.</span>)}
      {isStaff && <button type="button" className="esp-toggle" onClick={() => setEditing(true)} style={{ marginLeft: 0 }}>Composer / résultat</button>}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Carte d'une séance : infos + dispos                                */
/* ------------------------------------------------------------------ */
const STATUS = [
  { key: "yes", label: "Présent", cls: "yes" },
  { key: "maybe", label: "Peut-être", cls: "maybe" },
  { key: "no", label: "Absent", cls: "no" },
] as const;

async function toggleConvocation(sessionId: string, userId: string, on: boolean) {
  if (!supabase) return;
  if (on) await supabase.from("convocations").upsert({ session_id: sessionId, user_id: userId }, { onConflict: "session_id,user_id" });
  else await supabase.from("convocations").delete().eq("session_id", sessionId).eq("user_id", userId);
}

function SeanceCard({
  s, me, isStaff, avails, profiles, members, lineups, convocations, onRsvp, onDelete, onChange,
}: {
  s: Seance; me: string; isStaff: boolean;
  avails: Availability[]; profiles: Record<string, Profile>;
  members: Record<string, Profile>; lineups: Lineup[]; convocations: Convocation[];
  onRsvp: (sessionId: string, status: "yes" | "no" | "maybe") => void;
  onDelete: (id: string) => void; onChange: () => void;
}) {
  const [showList, setShowList] = useState(false);
  const [showConv, setShowConv] = useState(false);
  const convoked = convocations.filter((c) => c.session_id === s.id);
  const convokedIds = new Set(convoked.map((c) => c.user_id));
  const iAmConvoked = convokedIds.has(me);
  const memberList = Object.values(members).sort((a, b) => (a.pseudo || "").localeCompare(b.pseudo || ""));
  const mine = avails.find((a) => a.session_id === s.id && a.user_id === me)?.status;
  const forS = avails.filter((a) => a.session_id === s.id);
  const count = (st: string) => forS.filter((a) => a.status === st).length;

  return (
    <div className="esp-card esp-seance">
      <div className="esp-seance-head">
        <span className={"esp-badge esp-" + s.type}>{sessionTypeLabel(s.type)}</span>
        <span className="esp-date">{fmtDate(s.starts_at)} · {fmtHour(s.starts_at)}</span>
      </div>
      <h3>{s.title}{s.opponent ? <span className="esp-vs"> vs {s.opponent}</span> : null}</h3>
      <p className="esp-meta">
        {s.team ? <span>{teamLabel(s.team)}</span> : null}
        {s.location ? <span>· {s.location}</span> : null}
      </p>
      {s.notes ? <p className="esp-notes">{s.notes}</p> : null}

      {isCompetitive(s.type) && teamGame(s.team) !== "tft" && (
        <MatchCompo s={s} isStaff={isStaff} members={members} lineups={lineups} onChange={onChange} />
      )}

      {/* Convocations (staff désigne les joueurs appelés) */}
      {isStaff && (
        <div className="esp-conv">
          <button type="button" className="esp-toggle" onClick={() => setShowConv((v) => !v)}>
            {showConv ? "Fermer les convocations" : `Convoquer des joueurs (${convoked.length})`}
          </button>
          {showConv && (
            <div className="esp-conv-list">
              {memberList.length === 0 ? (
                <p className="muted" style={{ fontSize: ".85rem" }}>Aucun joueur dans cette équipe.</p>
              ) : memberList.map((m) => (
                <label key={m.id} className="esp-conv-item">
                  <input type="checkbox" checked={convokedIds.has(m.id)}
                    onChange={async (e) => { await toggleConvocation(s.id, m.id, e.target.checked); onChange(); }} />
                  <span>{m.pseudo}</span>
                </label>
              ))}
            </div>
          )}
          {convoked.length > 0 && !showConv && (
            <p className="esp-conv-names">Convoqués : {convoked.map((c) => profiles[c.user_id]?.pseudo || "—").join(", ")}</p>
          )}
        </div>
      )}
      {!isStaff && iAmConvoked && (
        <div className="esp-conv-you">📣 Tu es convoqué·e pour cette séance — confirme ta présence.</div>
      )}

      {/* Ma réponse */}
      <div className="esp-rsvp">
        {STATUS.map((st) => (
          <button key={st.key} type="button"
            className={"esp-rsvp-btn esp-" + st.cls + (mine === st.key ? " on" : "")}
            onClick={() => onRsvp(s.id, st.key)}>
            {st.label}
          </button>
        ))}
      </div>

      {/* Compteurs + vue staff */}
      <div className="esp-counts">
        <span className="esp-c esp-yes">{count("yes")} présents</span>
        <span className="esp-c esp-maybe">{count("maybe")} peut-être</span>
        <span className="esp-c esp-no">{count("no")} absents</span>
        {isStaff && forS.length > 0 && (
          <button type="button" className="esp-toggle" onClick={() => setShowList((v) => !v)}>
            {showList ? "Masquer" : "Voir qui"}
          </button>
        )}
      </div>
      {isStaff && showList && (
        <ul className="esp-people">
          {forS.map((a) => (
            <li key={a.id}><span className={"esp-dot esp-" + a.status}></span>{profiles[a.user_id]?.pseudo || "Joueur"} — {STATUS.find((x) => x.key === a.status)?.label}</li>
          ))}
        </ul>
      )}

      {isStaff && (
        <button type="button" className="esp-del" onClick={() => onDelete(s.id)}>Supprimer</button>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  DISPOS DE LA SEMAINE — grille récurrente (jour × créneau)          */
/* ------------------------------------------------------------------ */
type WeekSlot = { user_id: string; weekday: number; slot: string; status: "yes" | "maybe" };
const DAYS = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"];
const SLOTS = [
  { key: "aprem", label: "Après-midi", hours: "14h–18h" },
  { key: "soir", label: "Soirée", hours: "18h–21h" },
  { key: "nuit", label: "Nuit", hours: "21h–00h" },
] as const;

// Équipes Eden — source de vérité. `key` = identifiant stocké dans
// profiles.team / sessions.team / announcements.team ; `game` pilote les
// catalogues (agents Valorant, champions LoL) et le comportement (TFT = individuel).
type TeamGame = "valorant" | "lol" | "tft";
type TeamDef = { key: string; label: string; short: string; game: TeamGame };
const TEAMS: readonly TeamDef[] = [
  { key: "valorant-pro", label: "Valorant Pro", short: "VAL Pro", game: "valorant" },
  { key: "valorant-rising", label: "Valorant Rising", short: "VAL Rising", game: "valorant" },
  { key: "valorant-academie", label: "Valorant Académie", short: "VAL Acad", game: "valorant" },
  { key: "lol-pro", label: "League of Legends Pro", short: "LoL Pro", game: "lol" },
  { key: "lol-two", label: "League of Legends Two", short: "LoL Two", game: "lol" },
  { key: "lol-academique", label: "League of Legends Académique", short: "LoL Acad", game: "lol" },
  { key: "tft", label: "TFT", short: "TFT", game: "tft" },
] as const;

// Normalise une valeur stockée vers une clé d'équipe connue.
// Reconnaît les nouvelles clés (slugs) et rattrape les anciennes valeurs
// génériques (« Valorant » / « League of Legends ») vers l'équipe Pro par défaut.
function teamKey(t?: string | null): string {
  const s = (t || "").trim().toLowerCase();
  if (!s) return "";
  const direct = TEAMS.find((x) => x.key === s);
  if (direct) return direct.key;
  if (s.includes("valo")) return "valorant-pro";
  if (s.includes("lol") || s.includes("league")) return "lol-pro";
  if (s.includes("tft") || s.includes("teamfight")) return "tft";
  return "";
}
const teamDef = (t?: string | null): TeamDef | undefined => TEAMS.find((x) => x.key === teamKey(t));
const teamLabel = (t?: string | null) => teamDef(t)?.label || t || "";
const teamGame = (t?: string | null): TeamGame => teamDef(t)?.game || "valorant";

// Types de séance : pracc (entraînement), scrim, match, compétition.
const SESSION_TYPES: { key: SessionType; label: string; short: string }[] = [
  { key: "training", label: "Entraînement", short: "Pracc" },
  { key: "scrim", label: "Scrim", short: "Scrim" },
  { key: "match", label: "Match", short: "Match" },
  { key: "competition", label: "Compétition", short: "Compét." },
];
const sessionTypeLabel = (t?: string | null) => SESSION_TYPES.find((x) => x.key === t)?.label || "Séance";
// Séance « compétitive » = avec adversaire + feuille de match (tout sauf l'entraînement).
const isCompetitive = (t?: string | null) => t === "scrim" || t === "match" || t === "competition";

function WeeklyAvailability({ profile, profiles }: { profile: Profile; profiles: Record<string, Profile> }) {
  const [view, setView] = useState<"me" | "team">("me");
  const [slots, setSlots] = useState<WeekSlot[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState<string | null>(null); // "wd-slot" ouvert en vue équipe
  const totalMembers = Math.max(1, Object.keys(profiles).length);

  const load = useCallback(async () => {
    if (!supabase) return;
    setLoading(true);
    const { data } = await supabase.from("weekly_slots").select("user_id,weekday,slot,status");
    setSlots((data as WeekSlot[]) || []);
    setLoading(false);
  }, []);
  useEffect(() => { load(); }, [load]);

  const mine = (wd: number, sl: string) =>
    slots.find((s) => s.user_id === profile.id && s.weekday === wd && s.slot === sl)?.status;

  const cycle = async (wd: number, sl: string) => {
    if (!supabase) return;
    const cur = mine(wd, sl);
    const next = cur === undefined ? "yes" : cur === "yes" ? "maybe" : null; // dispo → peut-être → vide
    setSlots((prev) => {
      const others = prev.filter((s) => !(s.user_id === profile.id && s.weekday === wd && s.slot === sl));
      return next ? [...others, { user_id: profile.id, weekday: wd, slot: sl, status: next as "yes" | "maybe" }] : others;
    });
    if (next) {
      await supabase.from("weekly_slots").upsert(
        { user_id: profile.id, weekday: wd, slot: sl, status: next },
        { onConflict: "user_id,weekday,slot" }
      );
    } else {
      await supabase.from("weekly_slots").delete()
        .eq("user_id", profile.id).eq("weekday", wd).eq("slot", sl);
    }
  };

  // seuls les membres de l'équipe affichée (profiles est déjà filtré par équipe)
  const people = (wd: number, sl: string, st: "yes" | "maybe") =>
    slots.filter((s) => s.weekday === wd && s.slot === sl && s.status === st && profiles[s.user_id]);

  if (loading) return <p className="muted">Chargement…</p>;

  return (
    <div>
      <div className="esp-seg" style={{ marginBottom: "1rem" }}>
        <button className={view === "me" ? "on" : ""} onClick={() => setView("me")}>Mes dispos</button>
        <button className={view === "team" ? "on" : ""} onClick={() => setView("team")}>Vue équipe</button>
      </div>

      {view === "me" ? (
        <>
          <p className="muted" style={{ marginBottom: ".8rem", fontSize: ".9rem" }}>
            Clique une case pour indiquer ta dispo : 1 clic = <strong style={{ color: "#5bd08d" }}>Dispo</strong>,
            2 clics = <strong style={{ color: "#e8c35a" }}>Peut-être</strong>, 3 clics = vide.
            C&apos;est ta dispo <em>habituelle</em> de la semaine (modifiable à tout moment).
          </p>
          <div className="esp-week">
            <div className="esp-week-head"><span></span>{SLOTS.map((s) => <span key={s.key}>{s.label}<em className="esp-hrs">{s.hours}</em></span>)}</div>
            {DAYS.map((d, wd) => (
              <div className="esp-week-row" key={wd}>
                <span className="esp-week-day">{d}</span>
                {SLOTS.map((s) => {
                  const st = mine(wd, s.key);
                  return (
                    <button key={s.key} type="button"
                      className={"esp-cell" + (st ? " esp-" + st : "")}
                      onClick={() => cycle(wd, s.key)}
                      aria-label={`${d} ${s.label}`}>
                      {st === "yes" ? "✓" : st === "maybe" ? "~" : ""}
                    </button>
                  );
                })}
              </div>
            ))}
          </div>
        </>
      ) : (
        <>
          <p className="muted" style={{ marginBottom: ".8rem", fontSize: ".9rem" }}>
            Nombre de personnes dispo par créneau. Clique une case pour voir qui.
          </p>
          <div className="esp-week">
            <div className="esp-week-head"><span></span>{SLOTS.map((s) => <span key={s.key}>{s.label}<em className="esp-hrs">{s.hours}</em></span>)}</div>
            {DAYS.map((d, wd) => (
              <div className="esp-week-row" key={wd}>
                <span className="esp-week-day">{d}</span>
                {SLOTS.map((s) => {
                  const yes = people(wd, s.key, "yes");
                  const maybe = people(wd, s.key, "maybe");
                  const cellId = wd + "-" + s.key;
                  const ratio = yes.length / totalMembers;
                  const bg = yes.length === 0 ? "transparent"
                    : `rgba(91,208,141,${0.15 + Math.min(0.6, ratio * 0.7)})`;
                  return (
                    <button key={s.key} type="button" className="esp-cell esp-cell-team"
                      style={{ background: bg }}
                      onClick={() => setOpen(open === cellId ? null : cellId)}>
                      <strong>{yes.length}</strong>{maybe.length ? <span className="esp-cell-maybe">+{maybe.length}?</span> : null}
                    </button>
                  );
                })}
              </div>
            ))}
          </div>
          {open && (() => {
            const [wdS, slK] = open.split("-");
            const wd = parseInt(wdS, 10);
            const yes = people(wd, slK, "yes");
            const maybe = people(wd, slK, "maybe");
            const sl = SLOTS.find((x) => x.key === slK);
            return (
              <div className="esp-card" style={{ marginTop: "1rem" }}>
                <h3 style={{ fontSize: "1rem", marginBottom: ".6rem" }}>{DAYS[wd]} — {sl?.label} <span className="muted" style={{ fontWeight: 400 }}>({sl?.hours})</span></h3>
                {yes.length === 0 && maybe.length === 0 ? (
                  <p className="muted">Personne pour l&apos;instant.</p>
                ) : (
                  <ul className="esp-people">
                    {yes.map((p) => <li key={p.user_id}><span className="esp-dot esp-yes"></span>{profiles[p.user_id]?.pseudo || "Membre"}</li>)}
                    {maybe.map((p) => <li key={p.user_id}><span className="esp-dot esp-maybe"></span>{profiles[p.user_id]?.pseudo || "Membre"} <span className="muted">(peut-être)</span></li>)}
                  </ul>
                )}
              </div>
            );
          })()}
        </>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  ANNONCES INTERNES                                                  */
/* ------------------------------------------------------------------ */
function Announcements({ items, isStaff, team, onChange }: {
  items: Announcement[]; isStaff: boolean; team: string; onChange: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [scope, setScope] = useState<"team" | "all">("team");
  const [saving, setSaving] = useState(false);

  async function post(e: React.FormEvent) {
    e.preventDefault();
    if (!supabase || !title.trim()) return;
    setSaving(true);
    const { error } = await supabase.from("announcements").insert({
      team: scope === "all" ? null : team, title: title.trim(), body: body.trim(),
    });
    setSaving(false);
    if (!error) { setTitle(""); setBody(""); setOpen(false); onChange(); }
    else alert("Publication impossible : " + error.message);
  }
  async function del(id: string) {
    if (!supabase || !confirm("Supprimer cette annonce ?")) return;
    await supabase.from("announcements").delete().eq("id", id);
    onChange();
  }

  return (
    <section className="esp-block">
      <div className="esp-block-head">
        <h2>Annonces</h2>
        {isStaff && !open && <button className="btn btn--sm" onClick={() => setOpen(true)}>+ Annonce</button>}
      </div>
      {isStaff && open && (
        <form className="form esp-card" onSubmit={post} style={{ marginBottom: "1rem" }}>
          <div className="field"><label>Titre</label><input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="ex : Match ce dimanche" required /></div>
          <div className="field"><label>Message</label><textarea value={body} onChange={(e) => setBody(e.target.value)} placeholder="Détails de l'annonce…"></textarea></div>
          <div className="esp-seg">
            <button type="button" className={scope === "team" ? "on" : ""} onClick={() => setScope("team")}>{teamLabel(team)}</button>
            <button type="button" className={scope === "all" ? "on" : ""} onClick={() => setScope("all")}>Toutes les équipes</button>
          </div>
          <div style={{ display: "flex", gap: ".6rem", marginTop: ".8rem" }}>
            <button className="btn btn--sm" type="submit" disabled={saving}>{saving ? "Publication…" : "Publier"}</button>
            <button className="btn btn--ghost btn--sm" type="button" onClick={() => setOpen(false)}>Annuler</button>
          </div>
        </form>
      )}
      {items.length === 0 ? (
        <div className="esp-card esp-center"><p className="muted">Aucune annonce pour l&apos;instant.</p></div>
      ) : (
        <div className="esp-list">
          {items.map((a) => (
            <div className="esp-card esp-ann" key={a.id}>
              <div className="esp-ann-head">
                <h3>{a.title}</h3>
                {!a.team && <span className="esp-badge esp-training">Toutes équipes</span>}
              </div>
              <span className="esp-date">{fmtDate(a.created_at)}</span>
              {a.body ? <p className="esp-ann-body">{a.body}</p> : null}
              {isStaff && <button className="esp-del" onClick={() => del(a.id)}>Supprimer</button>}
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

/* ------------------------------------------------------------------ */
/*  ACCUEIL — cockpit (prochaines séances + dispo à confirmer)          */
/* ------------------------------------------------------------------ */
function HomeView({ profile, team, seances, avails, announcements, isStaff, onRsvp, onChangeAnn }: {
  profile: Profile; team: string; seances: Seance[]; avails: Availability[];
  announcements: Announcement[]; isStaff: boolean;
  onRsvp: (id: string, st: "yes" | "no" | "maybe") => void; onChangeAnn: () => void;
}) {
  const now = Date.now();
  const future = seances
    .filter((s) => teamKey(s.team) === team && new Date(s.starts_at).getTime() > now - 3 * 3600 * 1000)
    .sort((a, b) => +new Date(a.starts_at) - +new Date(b.starts_at));
  const nextTraining = future.find((s) => s.type === "training");
  const nextCompet = future.find((s) => isCompetitive(s.type));
  const nextAny = future[0];
  const myNext = nextAny ? avails.find((a) => a.session_id === nextAny.id && a.user_id === profile.id)?.status : undefined;

  const Mini = ({ s, kind }: { s?: Seance; kind: "training" | "compet" }) => (
    <div className="esp-card esp-mini">
      <span className={"esp-badge esp-" + (kind === "compet" ? "match" : "training")}>{kind === "compet" ? "Prochaine échéance" : "Prochain entraînement"}</span>
      {s ? (
        <>
          <div className="esp-mini-date">{fmtDate(s.starts_at)}</div>
          <div className="esp-mini-hour">{sessionTypeLabel(s.type)}{s.opponent ? ` · vs ${s.opponent}` : ""} — {fmtHour(s.starts_at)}</div>
          {s.location ? <div className="muted" style={{ fontSize: ".85rem" }}>{s.location}</div> : null}
        </>
      ) : <p className="muted" style={{ marginTop: ".6rem" }}>Rien de prévu.</p>}
    </div>
  );

  return (
    <div>
      <h2 style={{ marginBottom: "1rem" }}>Salut {profile.pseudo} 👋</h2>
      <div className="esp-home-grid">
        <Mini s={nextTraining} kind="training" />
        <Mini s={nextCompet} kind="compet" />
      </div>

      {nextAny && !myNext && (
        <div className="esp-card esp-confirm">
          <p>Tu n&apos;as pas encore répondu pour <strong>{sessionTypeLabel(nextAny.type)}</strong>{nextAny.opponent ? ` vs ${nextAny.opponent}` : ""} ({fmtDate(nextAny.starts_at)} · {fmtHour(nextAny.starts_at)}). Tu viens ?</p>
          <div className="esp-rsvp">
            {STATUS.map((st) => (
              <button key={st.key} type="button" className={"esp-rsvp-btn esp-" + st.cls}
                onClick={() => onRsvp(nextAny.id, st.key)}>{st.label}</button>
            ))}
          </div>
        </div>
      )}

      <Announcements items={announcements} isStaff={isStaff} team={team} onChange={onChangeAnn} />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  CALENDRIER MENSUEL + export .ics                                    */
/* ------------------------------------------------------------------ */
function CalendarView({ seances, team }: { seances: Seance[]; team: string }) {
  const [month, setMonth] = useState(() => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 1); });
  const teamSeances = seances.filter((s) => teamKey(s.team) === team);

  const y = month.getFullYear(), m = month.getMonth();
  const firstDow = (new Date(y, m, 1).getDay() + 6) % 7; // lundi=0
  const daysInMonth = new Date(y, m + 1, 0).getDate();
  const cells: (number | null)[] = [];
  for (let i = 0; i < firstDow; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  const sessionsOn = (d: number) => teamSeances.filter((s) => {
    const dt = new Date(s.starts_at);
    return dt.getFullYear() === y && dt.getMonth() === m && dt.getDate() === d;
  }).sort((a, b) => +new Date(a.starts_at) - +new Date(b.starts_at));

  const monthLabel = month.toLocaleDateString("fr-FR", { month: "long", year: "numeric" });
  const today = new Date();
  const isToday = (d: number) => today.getFullYear() === y && today.getMonth() === m && today.getDate() === d;

  return (
    <div>
      <div className="esp-cal-top">
        <div className="esp-cal-nav">
          <button className="btn btn--ghost btn--sm" onClick={() => setMonth(new Date(y, m - 1, 1))}>←</button>
          <strong style={{ textTransform: "capitalize", minWidth: 160, textAlign: "center" }}>{monthLabel}</strong>
          <button className="btn btn--ghost btn--sm" onClick={() => setMonth(new Date(y, m + 1, 1))}>→</button>
        </div>
        <button className="btn btn--sm" onClick={() => downloadICS(
          teamSeances.filter((s) => new Date(s.starts_at).getTime() > Date.now() - 24 * 3600 * 1000),
          teamLabel(team))}>📅 Ajouter à mon agenda</button>
      </div>
      <div className="esp-cal">
        <div className="esp-cal-dow">{["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"].map((d) => <span key={d}>{d}</span>)}</div>
        <div className="esp-cal-grid">
          {cells.map((d, i) => (
            <div className={"esp-cal-cell" + (d && isToday(d) ? " esp-cal-today" : "") + (d ? "" : " esp-cal-empty")} key={i}>
              {d && <span className="esp-cal-num">{d}</span>}
              {d && sessionsOn(d).map((s) => (
                <span key={s.id} className={"esp-cal-ev esp-" + s.type} title={`${fmtHour(s.starts_at)} ${s.title}`}>
                  {fmtHour(s.starts_at)} {s.type === "match" ? "🎮" : "🏋"}
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>
      <p className="muted" style={{ fontSize: ".85rem", marginTop: ".8rem" }}>
        « Ajouter à mon agenda » télécharge les séances à venir (fichier .ics) à importer dans Google Agenda / Apple Calendrier.
      </p>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  MON PROFIL (édition self-service)                                   */
/* ------------------------------------------------------------------ */
function MyProfileForm({ profile, onSaved, onCancel }: { profile: Profile; onSaved: () => void; onCancel: () => void }) {
  const [f, setF] = useState({
    pseudo: profile.pseudo || "", poste: profile.poste || "", rank: profile.rank || "",
    photo_url: profile.photo_url || "", socials: profile.socials || "", bio: profile.bio || "",
  });
  const [saving, setSaving] = useState(false);
  const set = (k: string, v: string) => setF((p) => ({ ...p, [k]: v }));

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!supabase) return;
    setSaving(true);
    const { error } = await supabase.from("profiles").update({
      pseudo: f.pseudo, poste: f.poste || null, rank: f.rank || null,
      photo_url: f.photo_url || null, socials: f.socials || null, bio: f.bio || null,
    }).eq("id", profile.id);
    setSaving(false);
    if (!error) onSaved();
    else alert("Enregistrement impossible : " + error.message);
  }

  return (
    <form className="form esp-card" onSubmit={save} style={{ marginBottom: "1.2rem" }}>
      <h3 style={{ marginBottom: ".8rem" }}>Mon profil</h3>
      <div className="esp-row">
        <div className="field"><label>Pseudo</label><input value={f.pseudo} onChange={(e) => set("pseudo", e.target.value)} required /></div>
        <div className="field"><label>Poste / rôle</label><input value={f.poste} onChange={(e) => set("poste", e.target.value)} placeholder="Duelist, Top…" /></div>
      </div>
      <div className="esp-row">
        <div className="field"><label>Rang</label><input value={f.rank} onChange={(e) => set("rank", e.target.value)} placeholder="Radiant, Diamant…" /></div>
        <div className="field"><label>Photo (lien)</label><input value={f.photo_url} onChange={(e) => set("photo_url", e.target.value)} placeholder="https://…" /></div>
      </div>
      <div className="field"><label>Réseaux (un par ligne : Label | lien)</label><textarea value={f.socials} onChange={(e) => set("socials", e.target.value)} placeholder="Twitch | https://twitch.tv/moi"></textarea></div>
      <div className="field"><label>Bio</label><textarea value={f.bio} onChange={(e) => set("bio", e.target.value)} placeholder="Quelques mots sur toi…"></textarea></div>
      <div style={{ display: "flex", gap: ".6rem" }}>
        <button className="btn btn--sm" type="submit" disabled={saving}>{saving ? "Enregistrement…" : "Enregistrer"}</button>
        <button className="btn btn--ghost btn--sm" type="button" onClick={onCancel}>Annuler</button>
      </div>
    </form>
  );
}

/* ------------------------------------------------------------------ */
/*  ÉQUIPE — roster interne                                             */
/* ------------------------------------------------------------------ */
async function moveMemberToTeam(userId: string, teamKeyVal: string) {
  if (!supabase) return;
  await supabase.from("profiles").update({ team: teamKeyVal }).eq("id", userId);
}

function RosterView({ members, me, isStaff, onSaved }: { members: Record<string, Profile>; me: Profile; isStaff: boolean; onSaved: () => void }) {
  const [editing, setEditing] = useState(false);
  const list = Object.values(members).sort((a, b) => (a.pseudo || "").localeCompare(b.pseudo || ""));

  return (
    <div>
      <div className="esp-block-head" style={{ marginBottom: "1rem" }}>
        <h2>L&apos;équipe</h2>
        {!editing && <button className="btn btn--sm" onClick={() => setEditing(true)}>Modifier mon profil</button>}
      </div>
      {editing && <MyProfileForm profile={me} onCancel={() => setEditing(false)} onSaved={() => { setEditing(false); onSaved(); }} />}
      {list.length === 0 ? (
        <div className="esp-card esp-center"><p className="muted">Aucun membre dans cette équipe pour l&apos;instant.</p></div>
      ) : (
        <div className="esp-roster">
          {list.map((p) => (
            <div className="esp-card esp-member" key={p.id}>
              <div className="esp-member-av">
                {p.photo_url ? <img src={p.photo_url} alt={p.pseudo} /> : <span>{(p.pseudo || "?").charAt(0).toUpperCase()}</span>}
              </div>
              <div className="esp-member-body">
                <div className="esp-member-top">
                  <strong>{p.pseudo}</strong>
                  {p.role === "staff" && <span className="esp-role esp-role-staff">Staff</span>}
                </div>
                <div className="muted" style={{ fontSize: ".85rem" }}>
                  {[p.poste, p.rank].filter(Boolean).join(" · ") || "—"}
                </div>
                {p.bio ? <p className="esp-member-bio">{p.bio}</p> : null}
                <SocialLinks socials={parseSocialsText(p.socials)} />
                {isStaff && (
                  <label className="esp-member-move">
                    <span className="muted" style={{ fontSize: ".78rem" }}>Équipe</span>
                    <select defaultValue={teamKey(p.team)} onChange={async (e) => { await moveMemberToTeam(p.id, e.target.value); onSaved(); }}>
                      {TEAMS.map((t) => <option key={t.key} value={t.key}>{t.label}</option>)}
                    </select>
                  </label>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  COMPOS / DRAFT — catalogues champions (LoL) & agents (Valorant)    */
/* ------------------------------------------------------------------ */
type CatItem = { key: string; name: string; icon: string; role?: string };
const CATALOG_CACHE: Record<string, CatItem[]> = {};
async function loadCatalog(game: string): Promise<CatItem[]> {
  if (CATALOG_CACHE[game]) return CATALOG_CACHE[game];
  try {
    if (game === "lol") {
      const vers = await fetch("https://ddragon.leagueoflegends.com/api/versions.json").then((r) => r.json());
      const ver = vers[0];
      const d = await fetch(`https://ddragon.leagueoflegends.com/cdn/${ver}/data/fr_FR/champion.json`).then((r) => r.json());
      const items = Object.values(d.data as Record<string, { id: string; name: string; image: { full: string } }>)
        .map((c) => ({ key: c.id, name: c.name, icon: `https://ddragon.leagueoflegends.com/cdn/${ver}/img/champion/${c.image.full}` }))
        .sort((a, b) => a.name.localeCompare(b.name));
      CATALOG_CACHE[game] = items; return items;
    }
    if (game === "valorant") {
      const d = await fetch("https://valorant-api.com/v1/agents?isPlayableCharacter=true&language=fr-FR").then((r) => r.json());
      const items = (d.data as { uuid: string; displayName: string; displayIcon: string; role?: { displayName: string } }[])
        .map((a) => ({ key: a.uuid, name: a.displayName, icon: a.displayIcon, role: a.role?.displayName }))
        .sort((a, b) => a.name.localeCompare(b.name));
      CATALOG_CACHE[game] = items; return items;
    }
  } catch { /* réseau indispo → repli saisie libre */ }
  return [];
}

const LOL_ROLES = ["TOP", "JGL", "MID", "BOT", "SUP"];
const VALO_MAPS = ["Ascent", "Bind", "Haven", "Split", "Icebox", "Breeze", "Fracture", "Lotus", "Pearl", "Sunset", "Abyss"];
type Pick = { role: string; key: string; name: string; icon?: string };

function ChampPicker({ game, value, onPick, placeholder }: {
  game: string; value?: { name?: string; icon?: string } | null; onPick: (v: CatItem) => void; placeholder?: string;
}) {
  const [cat, setCat] = useState<CatItem[]>([]);
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [failed, setFailed] = useState(false);
  useEffect(() => { let live = true; loadCatalog(game).then((c) => { if (!live) return; setCat(c); if (c.length === 0) setFailed(true); }); return () => { live = false; }; }, [game]);
  if (failed) return <input className="esp-input" placeholder={placeholder || "Nom"} value={value?.name || ""} onChange={(e) => onPick({ key: "", name: e.target.value, icon: "" })} />;
  const list = (q ? cat.filter((c) => c.name.toLowerCase().includes(q.toLowerCase())) : cat).slice(0, 60);
  return (
    <div className="esp-picker">
      <div className="esp-picker-val">
        {value?.icon ? <img src={value.icon} alt="" width={22} height={22} /> : null}
        <input className="esp-input" placeholder={placeholder || "Choisir…"} value={open ? q : (value?.name || "")}
          onFocus={() => { setOpen(true); setQ(""); }} onChange={(e) => setQ(e.target.value)}
          onBlur={() => setTimeout(() => setOpen(false), 160)} />
      </div>
      {open && (
        <div className="esp-picker-list">
          {list.map((c) => (
            <button type="button" key={c.key} className="esp-picker-item" onMouseDown={() => { onPick(c); setOpen(false); }}>
              <img src={c.icon} alt="" width={24} height={24} loading="lazy" /><span>{c.name}</span>{c.role ? <em>{c.role}</em> : null}
            </button>
          ))}
          {list.length === 0 && <span className="esp-picker-none">Aucun résultat</span>}
        </div>
      )}
    </div>
  );
}

/* --- Compositions d'équipe --- */
function CompsSection({ team, game, isStaff, meId }: { team: string; game: string; isStaff: boolean; meId: string }) {
  const [rows, setRows] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState(false);
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [opponent, setOpponent] = useState("");
  const [extra, setExtra] = useState("");
  const [notes, setNotes] = useState("");
  const [picks, setPicks] = useState<Pick[]>([]);
  const [bans, setBans] = useState<Pick[]>([]);
  const slots = game === "lol" ? LOL_ROLES : ["1", "2", "3", "4", "5"];

  const reset = () => { setName(""); setOpponent(""); setExtra(""); setNotes(""); setPicks([]); setBans([]); setOpen(false); };
  const load = useCallback(async () => {
    if (!supabase) return; setLoading(true);
    const r = await supabase.from("team_comps").select("*").eq("team", team).eq("game", game).order("created_at", { ascending: false });
    if (r.error) { setErr(true); setRows([]); } else { setErr(false); setRows((r.data as Record<string, unknown>[]) || []); }
    setLoading(false);
  }, [team, game]);
  useEffect(() => { load(); }, [load]);

  const setPick = (i: number, c: CatItem) => setPicks((p) => { const n = [...p]; n[i] = { role: slots[i], key: c.key, name: c.name, icon: c.icon }; return n; });
  const setBan = (i: number, c: CatItem) => setBans((p) => { const n = [...p]; n[i] = { role: "ban", key: c.key, name: c.name, icon: c.icon }; return n; });

  async function save() {
    if (!supabase || !name.trim()) return;
    const payload = {
      team, game, name: name.trim(), opponent: opponent.trim() || null,
      map: game === "valorant" ? (extra || null) : null, side: game === "lol" ? (extra || null) : null,
      picks: slots.map((role, i) => picks[i] || { role, key: "", name: "" }).filter((p) => p.name),
      bans: game === "lol" ? bans.filter((b) => b && b.name) : [],
      notes: notes.trim() || null,
    };
    const { error } = await supabase.from("team_comps").insert(payload);
    if (error) { alert("Enregistrement impossible : " + error.message); return; }
    reset(); load();
  }
  async function del(id: unknown) {
    if (!supabase || !confirm("Supprimer cette composition ?")) return;
    await supabase.from("team_comps").delete().eq("id", id); load();
  }

  if (err) return <div className="esp-card esp-center"><p className="muted">Module non activé (table « team_comps » absente). Lance le SQL fourni.</p></div>;
  if (loading) return <p className="muted">Chargement…</p>;
  return (
    <div>
      <div className="esp-compo-head">
        <button className="btn btn--sm" onClick={() => (open ? reset() : setOpen(true))}>{open ? "Fermer" : "+ Nouvelle compo"}</button>
      </div>
      {open && (
        <div className="esp-card esp-compo-form">
          <div className="esp-compo-row">
            <label className="esp-field"><span>Nom de la compo</span><input className="esp-input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex : Comp poke vs dive" /></label>
            <label className="esp-field"><span>Adversaire (optionnel)</span><input className="esp-input" value={opponent} onChange={(e) => setOpponent(e.target.value)} /></label>
            {game === "valorant" ? (
              <label className="esp-field"><span>Map</span><select className="esp-input" value={extra} onChange={(e) => setExtra(e.target.value)}><option value="">—</option>{VALO_MAPS.map((m) => <option key={m} value={m}>{m}</option>)}</select></label>
            ) : (
              <label className="esp-field"><span>Side</span><select className="esp-input" value={extra} onChange={(e) => setExtra(e.target.value)}><option value="">—</option><option value="Bleu">Bleu</option><option value="Rouge">Rouge</option></select></label>
            )}
          </div>
          <p className="esp-compo-lab">Picks</p>
          <div className="esp-compo-grid">
            {slots.map((role, i) => (
              <div key={role} className="esp-compo-slot">
                <span className="esp-compo-role">{role}</span>
                <ChampPicker game={game} value={picks[i]} onPick={(c) => setPick(i, c)} />
              </div>
            ))}
          </div>
          {game === "lol" && (
            <>
              <p className="esp-compo-lab">Bans (optionnel)</p>
              <div className="esp-compo-grid">
                {[0, 1, 2, 3, 4].map((i) => (
                  <div key={i} className="esp-compo-slot"><span className="esp-compo-role">Ban {i + 1}</span><ChampPicker game={game} value={bans[i]} onPick={(c) => setBan(i, c)} /></div>
                ))}
              </div>
            </>
          )}
          <label className="esp-field" style={{ marginTop: ".6rem" }}><span>Notes / plan de jeu</span><textarea className="esp-input" value={notes} onChange={(e) => setNotes(e.target.value)} /></label>
          <div style={{ display: "flex", gap: ".5rem", marginTop: ".6rem" }}>
            <button className="btn btn--sm" onClick={save} disabled={!name.trim()}>Enregistrer</button>
            <button className="btn btn--ghost btn--sm" onClick={reset}>Annuler</button>
          </div>
        </div>
      )}
      {rows.length === 0 ? <div className="esp-card esp-center"><p className="muted">Aucune composition pour l&apos;instant.</p></div> : (
        <div className="esp-compo-list">
          {rows.map((r) => {
            const rpicks = (r.picks as Pick[]) || []; const rbans = (r.bans as Pick[]) || [];
            const canDel = isStaff || r.author === meId;
            return (
              <div key={String(r.id)} className="esp-card esp-compo-card">
                <div className="esp-compo-cardhead">
                  <strong>{r.name as string}</strong>
                  <span className="muted">{[r.map, r.side, r.opponent ? "vs " + r.opponent : ""].filter(Boolean).join(" · ")}</span>
                  {canDel && <button className="esp-del" onClick={() => del(r.id)}>Supprimer</button>}
                </div>
                <div className="esp-compo-picks">
                  {rpicks.map((p, i) => (
                    <div key={i} className="esp-champ"><span className="esp-champ-role">{p.role}</span>{p.icon ? <img src={p.icon} alt="" width={40} height={40} /> : <span className="esp-champ-ph">{p.name.slice(0, 2)}</span>}<span className="esp-champ-name">{p.name}</span></div>
                  ))}
                </div>
                {rbans.length > 0 && <div className="esp-compo-bans">Bans : {rbans.map((b, i) => <img key={i} src={b.icon} alt={b.name} title={b.name} width={22} height={22} />)}</div>}
                {r.notes ? <p className="esp-compo-notes">{r.notes as string}</p> : null}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* --- Pools par joueur --- */
function PoolsSection({ team, game, isStaff, meId, members }: { team: string; game: string; isStaff: boolean; meId: string; members: Record<string, Profile> }) {
  const [rows, setRows] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState(false);
  const [role, setRole] = useState("");
  const load = useCallback(async () => {
    if (!supabase) return; setLoading(true);
    const r = await supabase.from("player_pool").select("*").eq("game", game);
    if (r.error) { setErr(true); setRows([]); } else { setErr(false); setRows((r.data as Record<string, unknown>[]) || []); }
    setLoading(false);
  }, [game]);
  useEffect(() => { load(); }, [load]);

  async function add(c: CatItem) {
    if (!supabase || !c.name) return;
    const { error } = await supabase.from("player_pool").upsert(
      { user_id: meId, game, champ_key: c.key || c.name, champ_name: c.name, icon: c.icon || null, role: role || null },
      { onConflict: "user_id,game,champ_key" });
    if (error) { alert("Ajout impossible : " + error.message); return; }
    load();
  }
  async function remove(id: unknown) { if (!supabase) return; await supabase.from("player_pool").delete().eq("id", id); load(); }

  if (err) return <div className="esp-card esp-center"><p className="muted">Module non activé (table « player_pool » absente). Lance le SQL fourni.</p></div>;
  if (loading) return <p className="muted">Chargement…</p>;
  const mine = rows.filter((r) => r.user_id === meId);
  // membres de l'équipe courante (+ moi)
  const teamIds = new Set(Object.keys(members));
  const byUser: Record<string, Record<string, unknown>[]> = {};
  for (const r of rows) { const u = r.user_id as string; if (!teamIds.has(u)) continue; (byUser[u] = byUser[u] || []).push(r); }
  return (
    <div>
      <div className="esp-card esp-compo-form">
        <p className="esp-compo-lab" style={{ marginTop: 0 }}>Mon pool ({game === "lol" ? "champions" : "agents"})</p>
        <div className="esp-pool-add">
          {game === "lol" && (
            <select className="esp-input" value={role} onChange={(e) => setRole(e.target.value)} style={{ maxWidth: 110 }}>
              <option value="">Rôle</option>{LOL_ROLES.map((r) => <option key={r} value={r}>{r}</option>)}
            </select>
          )}
          <ChampPicker game={game} onPick={add} placeholder={"Ajouter à mon pool…"} />
        </div>
        <div className="esp-pool-chips">
          {mine.length === 0 ? <span className="muted">Ton pool est vide — ajoute tes champions/agents.</span> :
            mine.map((r) => (
              <span key={String(r.id)} className="esp-poolchip">
                {r.icon ? <img src={r.icon as string} alt="" width={24} height={24} /> : null}
                {r.champ_name as string}{r.role ? <em>{r.role as string}</em> : null}
                <button onClick={() => remove(r.id)} aria-label="Retirer">✕</button>
              </span>
            ))}
        </div>
      </div>
      <p className="esp-compo-lab">Pools de l&apos;équipe</p>
      <div className="esp-pool-team">
        {Object.keys(byUser).length === 0 ? <p className="muted">Aucun pool renseigné dans l&apos;équipe.</p> :
          Object.entries(byUser).map(([uid, list]) => (
            <div key={uid} className="esp-card esp-pool-player">
              <strong>{members[uid]?.pseudo || "—"}</strong>
              <div className="esp-pool-chips">
                {list.map((r) => <span key={String(r.id)} className="esp-poolchip sm">{r.icon ? <img src={r.icon as string} alt="" width={20} height={20} /> : null}{r.champ_name as string}</span>)}
              </div>
            </div>
          ))}
      </div>
      {isStaff ? null : null}
    </div>
  );
}

function CompoView({ team, isStaff, meId, members }: { team: string; isStaff: boolean; meId: string; members: Record<string, Profile> }) {
  const [sub, setSub] = useState<"comps" | "pools">("comps");
  const game = teamGame(team); // 'valorant' | 'lol' | 'tft'
  if (game === "tft") {
    return (
      <div className="esp-card esp-center">
        <p className="muted">Le TFT est un format individuel : pas de composition d&apos;équipe ni de draft. Les résultats s&apos;enregistrent directement sur chaque séance/compétition.</p>
      </div>
    );
  }
  return (
    <div>
      <div className="esp-seg" style={{ marginBottom: "1rem" }}>
        <button className={sub === "comps" ? "on" : ""} onClick={() => setSub("comps")}>Compositions</button>
        <button className={sub === "pools" ? "on" : ""} onClick={() => setSub("pools")}>Pools joueurs</button>
      </div>
      {sub === "comps" ? <CompsSection team={team} game={game} isStaff={isStaff} meId={meId} />
        : <PoolsSection team={team} game={game} isStaff={isStaff} meId={meId} members={members} />}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  PLANNING GLOBAL — toutes les équipes réunies                       */
/* ------------------------------------------------------------------ */
function GlobalPlanning({ seances, isStaff, onDelete, onChange }: {
  seances: Seance[]; isStaff: boolean; onDelete: (id: string) => void; onChange: () => void;
}) {
  const [team, setTeam] = useState<string>("all");
  const [type, setType] = useState<string>("all");
  const now = Date.now();
  const list = seances
    .filter((s) => new Date(s.starts_at).getTime() > now - 3 * 3600 * 1000)
    .filter((s) => team === "all" || teamKey(s.team) === team)
    .filter((s) => type === "all" || s.type === type)
    .sort((a, b) => +new Date(a.starts_at) - +new Date(b.starts_at));

  const groups: { day: string; items: Seance[] }[] = [];
  for (const s of list) {
    const day = new Date(s.starts_at).toISOString().slice(0, 10);
    let g = groups.find((x) => x.day === day);
    if (!g) { g = { day, items: [] }; groups.push(g); }
    g.items.push(s);
  }

  return (
    <div>
      {isStaff && <CreateForm onCreated={onChange} defaultTeam={team === "all" ? TEAMS[0].key : team} />}
      <div className="esp-filters">
        <select value={team} onChange={(e) => setTeam(e.target.value)}>
          <option value="all">Toutes les équipes</option>
          {TEAMS.map((t) => <option key={t.key} value={t.key}>{t.label}</option>)}
        </select>
        <select value={type} onChange={(e) => setType(e.target.value)}>
          <option value="all">Tous les types</option>
          {SESSION_TYPES.map((t) => <option key={t.key} value={t.key}>{t.label}</option>)}
        </select>
        <span className="muted" style={{ fontSize: ".85rem", marginLeft: "auto" }}>{list.length} séance{list.length > 1 ? "s" : ""}</span>
      </div>
      {groups.length === 0 ? (
        <div className="esp-card esp-center"><p className="muted">Aucune séance à venir pour ce filtre.</p></div>
      ) : groups.map((g) => (
        <div key={g.day} className="esp-day">
          <div className="esp-day-head">{fmtDate(g.items[0].starts_at)}</div>
          <div className="esp-glist">
            {g.items.map((s) => {
              const def = teamDef(s.team);
              return (
                <div key={s.id} className="esp-grow">
                  <span className="esp-gtime">{fmtHour(s.starts_at)}</span>
                  <span className={"esp-gteam esp-game-" + (def?.game || "valorant")}>{def?.short || teamLabel(s.team) || "—"}</span>
                  <span className={"esp-badge esp-" + s.type}>{sessionTypeLabel(s.type)}</span>
                  <span className="esp-gtitle">{s.title}{s.opponent ? <em> vs {s.opponent}</em> : null}{s.location ? <span className="muted"> · {s.location}</span> : null}</span>
                  {isStaff && <button type="button" className="esp-gdel" title="Supprimer" onClick={() => onDelete(s.id)}>✕</button>}
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  MON PLANNING — ce qui concerne le joueur connecté                  */
/* ------------------------------------------------------------------ */
function MonPlanning({ me, seances, avails, convocations, onRsvp }: {
  me: Profile; seances: Seance[]; avails: Availability[]; convocations: Convocation[];
  onRsvp: (id: string, st: "yes" | "no" | "maybe") => void;
}) {
  const myTeam = teamKey(me.team);
  const now = Date.now();
  const convSet = new Set(convocations.filter((c) => c.user_id === me.id).map((c) => c.session_id));
  const mine = seances
    .filter((s) => new Date(s.starts_at).getTime() > now - 3 * 3600 * 1000)
    .filter((s) => teamKey(s.team) === myTeam || convSet.has(s.id))
    .sort((a, b) => +new Date(a.starts_at) - +new Date(b.starts_at));
  const myStatus = (id: string) => avails.find((a) => a.session_id === id && a.user_id === me.id)?.status;

  return (
    <div>
      <div className="esp-block-head" style={{ marginBottom: "1rem" }}>
        <h2>Mon planning</h2>
        {mine.length > 0 && <button className="btn btn--sm" onClick={() => downloadICS(mine, me.pseudo || "perso")}>📅 Ajouter à mon agenda</button>}
      </div>
      {mine.length === 0 ? (
        <div className="esp-card esp-center"><p className="muted">Rien de prévu pour toi pour l&apos;instant.</p></div>
      ) : (
        <div className="esp-glist">
          {mine.map((s) => {
            const convoked = convSet.has(s.id);
            const st = myStatus(s.id);
            const def = teamDef(s.team);
            return (
              <div key={s.id} className="esp-card esp-mine-row">
                <div className="esp-mine-top">
                  <span className="esp-gtime">{fmtDate(s.starts_at)} · {fmtHour(s.starts_at)}</span>
                  <span className={"esp-badge esp-" + s.type}>{sessionTypeLabel(s.type)}</span>
                  {convoked && <span className="esp-badge esp-conv-badge">📣 Convoqué</span>}
                </div>
                <div className="esp-mine-title">{def?.short ? def.short + " · " : ""}{s.title}{s.opponent ? <em> vs {s.opponent}</em> : null}{s.location ? <span className="muted"> · {s.location}</span> : null}</div>
                <div className="esp-rsvp">
                  {STATUS.map((x) => (
                    <button key={x.key} type="button" className={"esp-rsvp-btn esp-" + x.cls + (st === x.key ? " on" : "")} onClick={() => onRsvp(s.id, x.key)}>{x.label}</button>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Tableau de bord (connecté)                                         */
/* ------------------------------------------------------------------ */
function Dashboard({ profile, onLogout }: { profile: Profile; onLogout: () => void }) {
  const [tab, setTab] = useState<"home" | "global" | "mine" | "seances" | "week" | "calendar" | "compos" | "team">("home");
  const [team, setTeam] = useState<string>(teamKey(profile.team) || TEAMS[0].key);
  const [seances, setSeances] = useState<Seance[]>([]);
  const [avails, setAvails] = useState<Availability[]>([]);
  const [profiles, setProfiles] = useState<Record<string, Profile>>({});
  const [anns, setAnns] = useState<Announcement[]>([]);
  const [lineups, setLineups] = useState<Lineup[]>([]);
  const [convocations, setConvocations] = useState<Convocation[]>([]);
  const [loading, setLoading] = useState(true);
  const isStaff = profile.role === "staff";

  const load = useCallback(async () => {
    if (!supabase) return;
    setLoading(true);
    const since = new Date(Date.now() - 40 * 24 * 3600 * 1000).toISOString();
    const [ssR, avR, prof, annR, luR, cvR] = await Promise.all([
      supabase.from("sessions").select("*").gte("starts_at", since).order("starts_at", { ascending: true }),
      supabase.from("availabilities").select("*"),
      fetchProfiles(),
      supabase.from("announcements").select("*").order("created_at", { ascending: false }),
      supabase.from("match_lineup").select("*"),
      supabase.from("convocations").select("*"),
    ]);
    setSeances((ssR.data as Seance[]) || []);
    setAvails((avR.data as Availability[]) || []);
    const map: Record<string, Profile> = {};
    for (const p of prof) map[p.id] = p;
    setProfiles(map);
    setAnns((annR.data as Announcement[]) || []);
    setLineups((luR.data as Lineup[]) || []);
    setConvocations((cvR.data as Convocation[]) || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const onRsvp = async (sessionId: string, status: "yes" | "no" | "maybe") => {
    if (!supabase) return;
    // maj optimiste
    setAvails((prev) => {
      const others = prev.filter((a) => !(a.session_id === sessionId && a.user_id === profile.id));
      return [...others, { id: "tmp-" + sessionId, session_id: sessionId, user_id: profile.id, status, updated_at: new Date().toISOString() }];
    });
    await supabase.from("availabilities").upsert(
      { session_id: sessionId, user_id: profile.id, status },
      { onConflict: "session_id,user_id" }
    );
    load();
  };

  const onDelete = async (id: string) => {
    if (!supabase) return;
    if (!confirm("Supprimer cette séance ?")) return;
    await supabase.from("sessions").delete().eq("id", id);
    load();
  };

  const me = profiles[profile.id] || profile;
  // membres de l'équipe sélectionnée
  const teamMembers: Record<string, Profile> = {};
  for (const [id, p] of Object.entries(profiles)) if (teamKey(p.team) === team) teamMembers[id] = p;
  const annForTeam = anns.filter((a) => !a.team || teamKey(a.team) === team);
  const now = Date.now();
  const upcoming = seances
    .filter((s) => teamKey(s.team) === team && new Date(s.starts_at).getTime() > now - 3 * 3600 * 1000)
    .sort((a, b) => +new Date(a.starts_at) - +new Date(b.starts_at));

  const TABS: { key: typeof tab; label: string }[] = [
    { key: "home", label: "Accueil" },
    { key: "global", label: "Planning global" },
    { key: "mine", label: "Mon planning" },
    { key: "seances", label: "Séances" },
    { key: "week", label: "Dispos semaine" },
    { key: "calendar", label: "Calendrier" },
    { key: "compos", label: "Compos" },
    { key: "team", label: "Équipe" },
  ];

  return (
    <>
      <div className="esp-topbar">
        <div>
          <p className="eyebrow" style={{ margin: 0 }}>Espace équipe</p>
          <strong>{me.pseudo}</strong>
          <span className={"esp-role esp-role-" + me.role}>{isStaff ? "Staff" : "Joueur"}</span>
        </div>
        <button className="btn btn--ghost btn--sm" onClick={onLogout}>Se déconnecter</button>
      </div>

      {/* Sélecteur d'équipe : le staff bascule entre les 2, le joueur voit la sienne */}
      <div className="esp-teamsel">
        {isStaff ? (
          TEAMS.map((t) => (
            <button key={t.key} className={"esp-teambtn esp-game-" + t.game + (team === t.key ? " on" : "")}
              onClick={() => setTeam(t.key)}>{t.label}</button>
          ))
        ) : (
          <span className={"esp-teambtn esp-game-" + teamGame(team) + " on"} style={{ cursor: "default" }}>
            {teamLabel(team) || "Mon équipe"}
          </span>
        )}
      </div>

      <div className="esp-seg esp-tabs">
        {TABS.map((t) => (
          <button key={t.key} className={tab === t.key ? "on" : ""} onClick={() => setTab(t.key)}>{t.label}</button>
        ))}
      </div>

      {loading && tab !== "home" ? <p className="muted">Chargement…</p> : null}

      {tab === "home" && (
        <HomeView profile={me} team={team} seances={seances} avails={avails}
          announcements={annForTeam} isStaff={isStaff} onRsvp={onRsvp} onChangeAnn={load} />
      )}

      {tab === "seances" && (
        <>
          {isStaff && <CreateForm onCreated={load} defaultTeam={team} />}
          {upcoming.length === 0 ? (
            <div className="esp-card esp-center"><p className="muted">Aucune séance à venir pour le moment.</p></div>
          ) : (
            <div className="esp-list">
              {upcoming.map((s) => (
                <SeanceCard key={s.id} s={s} me={profile.id} isStaff={isStaff}
                  avails={avails} profiles={profiles} members={teamMembers} lineups={lineups} convocations={convocations}
                  onRsvp={onRsvp} onDelete={onDelete} onChange={load} />
              ))}
            </div>
          )}
        </>
      )}

      {tab === "global" && <GlobalPlanning seances={seances} isStaff={isStaff} onDelete={onDelete} onChange={load} />}
      {tab === "mine" && <MonPlanning me={me} seances={seances} avails={avails} convocations={convocations} onRsvp={onRsvp} />}
      {tab === "week" && <WeeklyAvailability profile={me} profiles={teamMembers} />}
      {tab === "calendar" && <CalendarView seances={seances} team={team} />}
      {tab === "compos" && <CompoView team={team} isStaff={isStaff} meId={profile.id} members={teamMembers} />}
      {tab === "team" && <RosterView members={teamMembers} me={me} isStaff={isStaff} onSaved={load} />}
    </>
  );
}

/* ------------------------------------------------------------------ */
/*  Racine de l'espace                                                 */
/* ------------------------------------------------------------------ */
export default function Espace() {
  const [ready, setReady] = useState(false);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [noProfile, setNoProfile] = useState(false);

  const loadProfile = useCallback(async () => {
    if (!supabase) { setReady(true); return; }
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) { setProfile(null); setNoProfile(false); setReady(true); return; }
    const { data } = await supabase.from("profiles").select("id,pseudo,role,team").eq("id", session.user.id).maybeSingle();
    if (data) { setProfile(data as Profile); setNoProfile(false); }
    else { setProfile(null); setNoProfile(true); }
    setReady(true);
  }, []);

  useEffect(() => {
    loadProfile();
    if (!supabase) return;
    const { data: sub } = supabase.auth.onAuthStateChange(() => loadProfile());
    return () => sub.subscription.unsubscribe();
  }, [loadProfile]);

  const logout = async () => { if (supabase) await supabase.auth.signOut(); setProfile(null); };

  if (!SUPABASE_ENABLED) return <NotConfigured />;
  if (!ready) return <p className="muted">Chargement…</p>;
  if (profile) return <Dashboard profile={profile} onLogout={logout} />;
  if (noProfile) {
    return (
      <div className="esp-card esp-center" style={{ maxWidth: 460, margin: "0 auto" }}>
        <h2>Compte à finaliser</h2>
        <p className="muted">Ton accès existe mais ton profil n&apos;est pas encore configuré. Contacte le staff pour qu&apos;il te rattache à une équipe.</p>
        <button className="btn btn--ghost btn--sm" onClick={logout} style={{ marginTop: "1rem" }}>Se déconnecter</button>
      </div>
    );
  }
  return <Login />;
}
