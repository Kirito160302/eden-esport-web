"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { CartBadge } from "./shop";

function ThemeToggle() {
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  useEffect(() => { setTheme(document.documentElement.getAttribute("data-theme") === "light" ? "light" : "dark"); }, []);
  function toggle() {
    const next = theme === "light" ? "dark" : "light";
    document.documentElement.setAttribute("data-theme", next);
    try { localStorage.setItem("eden-theme", next); } catch { /* ignore */ }
    setTheme(next);
  }
  return (
    <button className="theme-toggle" onClick={toggle} title="Mode clair / sombre"
      aria-label={theme === "light" ? "Passer en mode sombre" : "Passer en mode clair"}>
      {theme === "light"
        ? <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.7}><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z" /></svg>
        : <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.7}><circle cx="12" cy="12" r="4.2" /><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.4 1.4M17.6 17.6 19 19M19 5l-1.4 1.4M6.4 17.6 5 19" /></svg>}
    </button>
  );
}

type Child = { label: string; href: string; desc?: string };
type Item = { label: string; href: string; children?: Child[] };

const NAV: Item[] = [
  {
    label: "Eden", href: "/eden", children: [
      { label: "À propos d'Eden", href: "/eden", desc: "Notre histoire & notre vision" },
      { label: "Notre équipe", href: "/notre-equipe", desc: "Les visages de la structure" },
    ],
  },
  {
    label: "Esport", href: "/esport", children: [
      { label: "Nos équipes", href: "/esport", desc: "Rosters, palmarès & calendrier" },
      { label: "Nos joueurs", href: "/joueurs", desc: "Les profils compétitifs" },
      { label: "Recrutement", href: "/rejoindre", desc: "Rejoindre une équipe Eden" },
    ],
  },
  { label: "Événements", href: "/evenements" },
  {
    label: "Nos services", href: "/actions", children: [
      { label: "Vue d'ensemble", href: "/actions", desc: "Tout ce qu'Eden propose" },
      { label: "Organisation d'événements", href: "/services/organisation", desc: "Tournois, LAN & animations" },
      { label: "Ateliers & médiation", href: "/services/ateliers", desc: "Actions éducatives & jeunesse" },
      { label: "Consulting & accompagnement", href: "/services/consulting", desc: "Stratégie & production" },
    ],
  },
  {
    label: "Actualités", href: "/actualites", children: [
      { label: "Actualités", href: "/actualites", desc: "Le média Eden & esport" },
      { label: "Blog", href: "/blog", desc: "Guides, analyses & coulisses" },
    ],
  },
  { label: "Boutique", href: "/boutique" },
  { label: "Partenaires", href: "/partenaires" },
];

// Regroupe les sous-routes sous l'onglet parent pour l'état actif.
const GROUP: Record<string, string> = {
  "/eden": "/eden", "/notre-equipe": "/eden",
  "/esport": "/esport", "/equipes": "/esport", "/joueurs": "/esport",
  "/evenements": "/evenements",
  "/actions": "/actions", "/services": "/actions",
  "/actualites": "/actualites", "/blog": "/actualites",
  "/boutique": "/boutique", "/panier": "/boutique",
  "/partenaires": "/partenaires",
};

function activeHref(pathname: string): string | null {
  const seg = "/" + (pathname.split("/").filter(Boolean)[0] ?? "");
  return GROUP[seg] ?? null;
}

export default function Header() {
  const pathname = usePathname() || "/";
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [openSub, setOpenSub] = useState<string | null>(null);
  const active = activeHref(pathname);
  const internal = /^\/(espace|bureau|club)/.test(pathname);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
  }, [open]);

  // Ferme les menus à chaque changement de page
  useEffect(() => { setOpen(false); setOpenSub(null); }, [pathname]);

  // Vue publique des tournois = plein écran (pas d'en-tête de site)
  if (/^\/tournoi(\/|$)/.test(pathname)) return null;

  return (
    <>
      <header className={"header" + (scrolled ? " scrolled" : "")} data-theme={internal ? "dark" : undefined}>
        <div className="wrap">
          <Link href="/" className="brand" title="Eden Esport — accueil">
            <img src="/symbol.png" alt="" width={38} height={38} aria-hidden="true" />
            <span className="wm">EDEN<small>E-SPORT</small></span>
          </Link>

          <nav className="nav" aria-label="Navigation principale">
            {NAV.map((item) => (
              <div className={"nav-item" + (item.children ? " has-menu" : "")} key={item.href + item.label}>
                <Link href={item.href} className={active === item.href ? "on" : ""}>
                  {item.label}
                  {item.children && <span className="caret" aria-hidden="true"></span>}
                </Link>
                {item.children && (
                  <div className="nav-panel" role="menu">
                    <div className="nav-panel-inner">
                      {item.children.map((c) => (
                        <Link key={c.href + c.label} href={c.href} className="nav-sub" role="menuitem">
                          <span className="nav-sub-label">{c.label}</span>
                          {c.desc && <span className="nav-sub-desc">{c.desc}</span>}
                        </Link>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </nav>

          <div className="header-cta">
            {!internal && <ThemeToggle />}
            <CartBadge />
            <Link href="/rejoindre" className="btn btn--sm">Rejoindre Eden<span className="arw">→</span></Link>
            <button className="burger" aria-label="Ouvrir le menu" aria-expanded={open}
              onClick={() => setOpen((v) => !v)}>
              <span></span><span></span><span></span>
            </button>
          </div>
        </div>
      </header>

      <div className={"mobile-menu" + (open ? " open" : "")} aria-hidden={!open} inert={!open ? true : undefined}>
        {NAV.map((item, i) => (
          <div className="mm-item" key={item.href + item.label}>
            <div className="mm-row">
              <Link href={item.href} className="mm-main">{item.label} <span>{String(i + 1).padStart(2, "0")}</span></Link>
              {item.children && (
                <button className={"mm-toggle" + (openSub === item.label ? " open" : "")} type="button"
                  aria-label={`Sous-menu ${item.label}`} aria-expanded={openSub === item.label}
                  onClick={() => setOpenSub((v) => (v === item.label ? null : item.label))}>
                  <span className="caret" aria-hidden="true"></span>
                </button>
              )}
            </div>
            {item.children && openSub === item.label && (
              <div className="mm-sub">
                {item.children.map((c) => (
                  <Link key={c.href + c.label} href={c.href}>{c.label}</Link>
                ))}
              </div>
            )}
          </div>
        ))}
        <Link href="/rejoindre" className="btn">Rejoindre Eden<span className="arw">→</span></Link>
      </div>
    </>
  );
}
